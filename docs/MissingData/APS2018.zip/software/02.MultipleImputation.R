## Terrence D. Jorgensen
## University of Amsterdam, Dept. of Child Development and Education
## http://www.uva.nl/en/profile/j/o/t.d.jorgensen/t.d.jorgensen.html
## Last updated: 20 June 2018
## R syntax to illustrate Multiple Imputation for APS Missing Data Workshop:
## State-of-the-Art Methods for Handling Missing Data Responsibly in SPSS or R

## This file contains R syntax that is explained in "02.ImputeMissingData.html"

## If necessary, paste the path to your data inside the quotation marks
setwd("../software/")
## Use the foreign package to import the "wintergreen.sav" data,
## provided with Huberty & Olejnik's (2006) textbook, accessible here:
## ftp://ftp.wiley.com/public/sci_tech_med/applied_manova/
library(foreign)
school <- read.spss("wintergreen.sav", to.data.frame = TRUE,
                    use.value.labels = FALSE)



## ---------------------------------------------------------------------
## Experiment with 2-level imputation and using composites as predictors
## ---------------------------------------------------------------------

school1 <- school
school2 <- school
school3 <- school

set.seed(12345)
school2$G <- sample(school2$G)
school3$G <- sample(school3$G)
schools <- rbind(school1, school2, school3)
schools$G[sample(1:nrow(schools), size = .1*nrow(schools))] <- NA
schools$AA <- schools$AA + rnorm(nrow(schools),
                                 sd = sqrt(.1 * var(school$AA, na.rm = TRUE)))
schools$PE <- schools$PE + rnorm(nrow(schools),
                                 sd = sqrt(.1 * var(school$PE, na.rm = TRUE)))

schools$religion <- factor(schools$R, levels = c(0, 1, 2),
                           labels = c("Catholic","Protestant","Jewish"))
schools$sex <- factor(schools$G, levels = c(0, 1), labels = c("Male","Female"))
schools$community <- factor(schools$C, levels = c(0, 1),
                            labels = c("Urban","Rural"))

schools$motivation <- ordered(schools$SM, levels = c(0, 1, 2),
                              labels = c("Unwilling","Undecided","Willing"))
schools$evaluation <- ordered(schools$AE, levels = c(0, 1, 2),
                              labels = c("Fail","Might Succeed","Succeed"))
schools <- schools[ , -4:-8]
sapply(schools, function(i) sum(is.na(i)))


library(mice)

formulaList <- list(RESP_NUM = RESP_NUM ~ 1,
  AA         = AA ~ sex + motivation + PE + religion + evaluation + community + (1 | RESP_NUM),
  PE         = PE ~ sex + motivation + AA + religion + evaluation + community + (1 | RESP_NUM),
  sex        = sex ~ motivation + I(AA + PE) + religion + evaluation + community + (1 | RESP_NUM),
  motivation = motivation ~ 1,
  evaluation = evaluation ~ 1,
  religion   = religion ~ sex*motivation + I(AA + PE) + religion + evaluation + community + (1 | RESP_NUM),
  community  = community ~ sex*motivation + I(AA + PE) + religion + evaluation + community + (1 | RESP_NUM))
methodList <- c(RESP_NUM = "",
                AA         = "2l.lmer",
                PE         = "2l.lmer",
                sex        = "2l.bin",
                motivation = "",
                evaluation = "",
                religion   = "2lonly.pmm",
                community  = "2lonly.pmm")
## ignore multilevel
formulaList <- list(RESP_NUM = RESP_NUM ~ 1,
  AA         = AA ~ sex + motivation + PE + religion + evaluation + community,
  PE         = PE ~ sex + motivation + AA + religion + evaluation + community,
  sex        = sex ~ motivation + I(AA + PE) + religion + evaluation + community,
  motivation = motivation ~ 1,
  evaluation = evaluation ~ 1,
  religion   = religion ~ 1,
  community  = community ~ 1)
methodList <- c(RESP_NUM = "",
                AA         = "norm",
                PE         = "norm",
                sex        = "logreg",
                motivation = "",
                evaluation = "",
                religion   = "",
                community  = "")

nImps <- 5 # number of imputations
out.mice <- mice(schools, m = nImps, seed = 12345, printFlag = FALSE,
                 form = formulaList, method = methodList)




## ------------------------------------------
## Changing Data Types to the Correct `class`
## ------------------------------------------

## Before imputing data, we need to make sure the variables will be treated
## correctly (e.g., `R` and `G` should be treated as categorical, not numeric).

## Save copies of nominal variables as labeled `factor` variables.
school$religion <- factor(school$R, levels = c(0, 1, 2),
                          labels = c("Catholic","Protestant","Jewish"))
school$sex <- factor(school$G, levels = c(0, 1), labels = c("Male","Female"))
school$community <- factor(school$C, levels = c(0, 1),
                           labels = c("Urban","Rural"))

## Save copies of ordinal variables as labeled `ordered` `factor` variables.
school$motivation <- ordered(school$SM, levels = c(0, 1, 2),
                             labels = c("Unwilling","Undecided","Willing"))
school$evaluation <- ordered(school$AE, levels = c(0, 1, 2),
                             labels = c("Fail","Might Succeed","Succeed"))

## The variables `SM`, `AE`, `R`, `G`, and `C` are stored as `numeric` vectors,
## so they will not be treated correctly in the imputation procedures described
## below.  That is, only continuous variables should be treated as `numeric`,
## whereas nominal and ordinal `factor`s should be treated as having discrete
## categories.  Because `SM`, `AE`, `R`, `G`, and `C` are redundant with the
## variables `motivation`, `evaluation`, `religion`, `sex`, and `community`,
## respectively, we will simplify the presentation by removing the old columns
## `SM`, `AE`, `R`, `G`, and `C`.
school <- school[ , -4:-8]
head(school)



## ----------------------
## Summarize Missing Data
## ----------------------

## Identifying missing values can be done with the logical function is.na()
is.na(school$AA)
which(is.na(school$AA))

## User-defined function to summarize missingness on a single variable
propMiss <- function(x) {
  c(N = length(x), N.obs = sum(!is.na(x)),
    N.miss = sum(is.na(x)), Proportion.miss = mean(is.na(x)))
}
## Test it out on one variable
propMiss(school$AA)
## Now you can apply it to  each variable
sapply(school, propMiss)


## Both multiple-imputation packages I introduce below (`Amelia` and `mice`)
## provide some additional ways to summarize missing-data proportions or
## patterns, which you might find useful in more complicated circumstances.
install.packages(c("Amelia","mice")) # only need to install the first time

## `Amelia` provides a plot showing the "holes" in the `data.frame`
library(Amelia)
missmap(school)

## `mice` provides a table in which:
## - each row is a missing-data pattern
## - the left column is how many people have that pattern
## - the right column is how many variables are missing for that pattern
## - the bottom row is how many people are missing data for that variable
library(mice)
md.pattern(school)



## -------------------------------------------------
## Multiple Imputation with Chained Equations (MICE)
## -------------------------------------------------

## Chained equations apply a different imputation model for each variable, so
## appropriate values can be predicted for continuous, nominal, ordinal, and
## count variables.  There is no argument in mice() function to declare an
## ID variable, but a predictor matrix can be specified that tells mice() not
## to use the ID variable as a predictor in any imputation model.
predMat <- matrix(1, nrow = ncol(school), ncol = ncol(school)) # 1 means "yes"
predMat[ , 1] <- 0 # 0 means "no"
## also, ID should not be imputed, so nothing should predict it
predMat[1, ] <- 0
## And no variable should ever predict itself
diag(predMat) <- 0
predMat
## This predictor matrix only allows main effects of each variable to be
## included or excluded.  To specify a more complex model, users can specify
## a `formula` for each outcome in a vector of `character` strings.

## For example, to include a 2-way interaction between `sex` and `religion`
## (`sex*motivation`) but only main effects of other variables:
formulaList <- list(RESP_NUM = "",
 AA         = "~ sex*motivation + AA + PE + religion + evaluation + community",
 PE         = "~ sex*motivation + AA + PE + religion + evaluation + community",
 motivation = "~ sex*motivation + AA + PE + religion + evaluation + community",
 evaluation = "~ sex*motivation + AA + PE + religion + evaluation + community",
 religion   = "~ sex*motivation + AA + PE + religion + evaluation + community",
 sex        = "~ sex*motivation + AA + PE + religion + evaluation + community",
 community  = "~ sex*motivation + AA + PE + religion + evaluation + community")
## Notice that no predictors were specified for the ID variable `RESP_NUM`.


## Because the variables are explicitly declared as nominal or ordinal factors,
## `mice()` will automatically choose appropriate imputation models.
sapply(school, class)
## However, the `method=` argument can be used to explicitly declare the types
## of model used for each variable, if necessary (e.g., for multilevel data).
## You would simply create a vector of `character` strings specifying the model
## for each variable, similar to the vector of `formula`s above (`formulaList`).

## Below, we impute the missing values `m = 5` times for simplicity, but in
## practice, `m = 100` is recommended to create a more representative sample
## of the possible values that could have been observed.  The `seed=` argument
## is used to make sure the same results can be replicated. The integer used
## (`12345`) is arbitrary, but using the same integer will reproduce results
## exactly.
nImps <- 5 # number of imputations
out.mice <- mice(school, m = nImps, seed = 12345,
                 # predictorMatrix = predMat, # un-comment to omit interactions
                 form = formulaList,         # comment-out to omit interactions
                 printFlag = FALSE)

## Next, we can fit a regression model to each imputed data set
(outList.mice <- with(data = out.mice, expr = lm(AA ~ motivation * sex)))

## The variability of results across imputations reflects the uncertainty due
## to missing data.  Use the `pool()` function to combine results across
## imputations. The `summary()` function returns *t* statistics and *p* values
## for null hypothesis significance tests (NHST) of individual coefficients.
pooled.mice <- pool(outList.mice)
summary(pooled.mice)

## If you need the list of imputed data sets for any reason, you can
## extract imputed ("completed") data sets from the output object by
## applying the `complete()` function in a `for`-loop:
imps.mice <- list()
for (i in 1:nImps) imps.mice[[i]] <- complete(out.mice, action = i)
## view the last few rows of each imputation
lapply(imps.mice, tail)
## compare to original data
tail(school)



## ----------------------------------------------------------
## Amelia: multiple imputation using a bootstrap-EM algorithm
## ----------------------------------------------------------

## This package transforms nominal variables into dummy codes, and ordinal
## variables are treated as having an underlying normal distribution, then
## the imputations are rounded so they fit into the ordinal categories.
## ID variables can be declared so that they are ignored.

## Before imputing data, you should choose a "Seed" so that you can
## reproduce your results (so no one can claim you "made up the data").
## Whereas the `mice()` function has an explicit argument to set the seed,
## if you use `amelia()` you must set the seed before running the function.
set.seed(12345)

## When imputing the missing data with Amelia, notice that we explicitly tell
## her that `RESP_NUM` is an ID variable; `religion`, `sex`, and `community`
## are nominal factors; and `motivation` and `evaluation` are ordered factors.
## Any variables not explicitly declared this way are assumed continuous.
out.amelia <- amelia(school, m = nImps, idvars = "RESP_NUM",
                     noms = c("religion","sex","community"),
                     ords = c("motivation","evaluation"))
summary(out.amelia)


## Unlike the `mice()` output, `amelia()` output already contains a `list` of
## imputations.  Extract imputed datasets from the output object.
imps.amelia <- out.amelia$imputations
## view the last few rows of each imputation
lapply(imps.amelia, tail)
## compare to original data
tail(school)



## `Amelia` does not provide an easy way to fit a model to each imputation.
## Fit the regression model to all imputed data sets
(outList.amelia <- lapply(imps.amelia,
                          function(d) lm(AA ~ sex * motivation, data = d)))
## Save list of coefficients and standard errors
(coefList.amelia <- sapply(outList.amelia, coef))
(seList.amelia <- sapply(outList.amelia, function(x) sqrt(diag(vcov(x)))))
## The `mi.meld()` function can combine coefficients and SEs across imputations
(pooled.amelia <- mi.meld(q = coefList.amelia, se = seList.amelia, byrow = FALSE))
## But it does not provide appropriate significance tests for NHST.
## Calculate the t statistics for NHST:
pooled.amelia$q.mi / pooled.amelia$se.mi
## calculating the correct degrees of freedom is complicated, but these
## t values are quite large.

## Even the `mice` package only provides appropriate test statistics for
## individual coefficients.  ANOVA involves testing multiple regression
## coefficients simultaneously. In the example above, the effect of `motivation`
## (a 3-group variable) is modeled using $k-1=2$ dummy codes, and `sex` is
## modeled using 1 dummy code.  The *df* for each of those effects is then 2
## and 1, respectively, and the interation effect also has 2 *df* because it is
## modeled by multiplying the 2 `motivation` dummy codes by the `sex` dummy
## code.  Testing the interaction (or any other effect) means testing
## simultaneously whether both coefficients equal zero (implying no differences
## between any groups, or no interaction). The method is described in:

## van Ginkel & Kroonenberg (2014) Analysis of variance of multiply imputed
##      data. Multivariate Behavioral Research, 49, 78-91.



## ---------------------
## Pooling ANOVA results
## ---------------------

## The `mitml` package (Multiple Imputation Tools for Multi-Level data)
## provides pooled ANOVA tests.  The next section shows how to use it.

install.packages("mitml")
library(mitml)

## First, you convert the `amelia()` or `mice()` output to the required format
imps.amelia <- amelia2mitml.list(out.amelia) # amelia() output
imps.mice   <-   mids2mitml.list(out.mice)   #   mice() output


## As before, we can fit a regression model to each imputed data set,
## and we can test each estimate, this time using `testEstimates()`
outList <-  with(data = imps.mice, expr = lm(AA ~ motivation * sex))
testEstimates(outList)


## But to test the interaction, we need a simultaneous test of whether both
## terms (`motivation2:sex2` and `motivation3:sex2`) are zero.  We can test
## this null hypothesis by comparing our model with the interaction to a
## model without the interation (i.e., in which the null hypothesis is true).
outList0 <-  with(data = imps.mice, expr = lm(AA ~ motivation + sex))
testModels(outList, outList0)
## We cannot reject the null hypothesis, so we will retain the simpler model.


## We can use the `testConstraints()` function to test the main effect of
## `motivation`.
testConstraints(outList0, constraints=c("motivation2","motivation3"))
## We can reject the null hypothesis that `motivation` has no effect.


## The effect of sex is represented with only one dummy code, so we can obtain
## the same test using either `testEstimates()` for a *t* test or
## `testConstraints()` for an *F* test (which is the square of the *t* value).
testEstimates(outList0)
testConstraints(outList0, constraints = "sex2")
## We cannot reject the null hypothesis that `sex` has no effect.








