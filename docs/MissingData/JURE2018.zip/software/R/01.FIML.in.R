## Terrence D. Jorgensen
## University of Amsterdam, Dept. of Child Development and Education
## http://www.uva.nl/en/profile/j/o/t.d.jorgensen/t.d.jorgensen.html
## Last updated: 27 June 2018
## R syntax to illustrate Multiple Imputation for EARLI-JURE Workshop:
## Handling Missing Data Responsibly with Structural Equation Modeling in R

## This file contains R syntax that is explained in "03.MaximumLikelihood.html"

## If necessary, paste the path to your data inside the quotation marks
setwd("../R/")
## Import the "school.dat" data provided with Huberty & Olejnik's (2006)
## textbook, accessible here as "wintergreen.sav":
## ftp://ftp.wiley.com/public/sci_tech_med/applied_manova/
school <- read.table("school.dat", header = FALSE, na.strings = "-999",
                     col.names = c("ID","AA","PE","SM","AE","R","G","C"))


## Full-Information Maximum Likelihood (FIML) is only implemented in
## structural equation modeling (SEM) software. Luckily, regression models
## are special cases of SEM, so we can still test ANOVA this way.

## To incorporate categorical predictors into a lavaan model to use full
## information maximum likelihood, we must make dummy codes.
school$Male <- ifelse(school$G == 0, yes = 1, no = 0)
school$Willing <- ifelse(school$SM == 2, yes = 1, no = 0)
school$Unwilling <- ifelse(school$SM == 0, yes = 1, no = 0)
## also need interactions?  (not in latest version of lavaan)
# school$Willing_Male <- school$Willing * school$Male
# school$Unwilling_Male <- school$Unwilling * school$Male
head(school)



## ------------------------------------------
## Full-Information Maximum Likelihood (FIML)
## ------------------------------------------

install.packages("lavaan")
# install.packages("lavaan", repos="http://www.da.ugent.be", type="source")
library(lavaan)

## Whereas regression models must be specified with a single formula that
## specifies all slopes, lavaan syntax is a character string that can
## specify each slope, one at a time. Use the `:` operator to create product
## terms to represent the interaction effect.
model <- '
  ## specify main effects
    AA ~ Male
    AA ~ Willing + Unwilling
  ## specify interaction effects using ":"
    AA ~ Male:Willing + Male:Unwilling
'
## To test whether effects can be dropped from the model, add labels to
## the slope parameters (e.g., the effect of `sex` can be labeled by adding
## that label to the `AA ~ Male` parameter: `AA ~ sex*Male`).  Below, we
## replace our model syntax with one that labels the parameters.
model <- '
  ## label main effects
    AA ~ sex*Male
    AA ~ motiv1*Willing + motiv2*Unwilling
  ## label interaction effects using ":"
    AA ~ int1*Male:Willing + int2*Male:Unwilling
'
## When we fit the model to data, tell lavaan to handle missing data using FIML
fit <- sem(model, data = school, missing = "FIML")
summary(fit, rsquare = TRUE)
## Notice the slope labels are truncated in the output.

## We can use the labels to get ANOVA tests
test.int <- '
  int1 == 0
  int2 == 0
'
lavTestWald(fit, constraints = test.int)
## Note that this is a chi-squared test statistic, not an F statistic.

## Cannot reject null hypothesis, so remove the interaction from the model
model0 <- '
  ## label main effects
    AA ~ sex*Male
    AA ~ motiv1*Willing + motiv2*Unwilling
'
fit0 <- sem(model0, data = school, missing = "FIML")
summary(fit0, rsquare = TRUE) # Male slope is not significant
## test effect of motivation
test.main <- '
  motiv1 == 0
  motiv2 == 0
'
lavTestWald(fit0, constraints = test.main) # significant



## An alternative to the Wald test (which only requires fitting an
## unrestricted model) is a Likelihood Ratio Test (LRT), which also
## requires fitting a restricted model **to the same variables** that
## represents the null hypothesis:
restricted.model <- '
  ## label main effects
AA ~ sex*Male
AA ~ motiv1*Willing + motiv2*Unwilling
## label interaction effects using ":"
AA ~ 0*Male:Willing + 0*Male:Unwilling
'
## Notice that instead of labels, we fixed the slopes of the interaction
## terms to be 0.  After fitting this model, we can use anova() to
## compare them.
restricted.fit <- sem(restricted.model, data = school, missing = "FIML")
anova(fit, restricted.fit)
## Notice how similar the LRT result is to the Wald test result:
lavTestWald(fit, constraints = test.int)
## The LRT is useful when testing hypotheses that involve many parameters,
## or to compare models that are not nested in a simple way.



## -----------------------------
## FIML with Auxiliary Variables
## -----------------------------

## Including auxiliary variables can help justify MAR assumption.
## To automatically add auxiliary variables to your model without changing
## the interpretation of your parameters or the degrees of freedom,
## use the `auxiliary()` function in the `semTools` package:
install.packages("semTools")
# devtools::install_github("simsem/semTools/semTools")
library(semTools)

## The model and constraints are already defined in the previous section.
## Below, I merely run the sem.auxiliary() function instead of sem()

## Just provide the names of auxiliary variable(s) -- here, we use the
## variables PE (continuous), AE (ordinal), and C (binary. FIML assumes that
## outcome and auxiliary variables are normally distributed, so we cannot
## include our nominal variable (R) unless we use multiple impuation, or
## make dummy codes for 2 of the groups.
fit.aux <- sem.auxiliary(model, data = school, aux = c("PE","AE","C"))
lavTestWald(fit.aux, constraints = test.int)
## Still cannot reject null hypothesis, so remove the interaction

fit0.aux <- sem.auxiliary(model0, data = school, aux = c("PE","AE","C"))
summary(fit0.aux, rsquare = TRUE) # Male slope is still not significant
## Notice all the additional parameters that are now automatically added to the
## model?  Those could account for missingness, improving estimation.

## test effect of motivation
lavTestWald(fit0.aux, constraints = test.main) # still significant



