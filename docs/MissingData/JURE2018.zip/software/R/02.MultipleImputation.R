## Terrence D. Jorgensen
## University of Amsterdam, Dept. of Child Development and Education
## http://www.uva.nl/en/profile/j/o/t.d.jorgensen/t.d.jorgensen.html
## Last updated: 27 June 2018
## R syntax to illustrate Multiple Imputation for EARLI-JURE Workshop:
## Handling Missing Data Responsibly with Structural Equation Modeling in R

## This file contains R syntax that is explained in "02.ImputeMissingData.html"

## If necessary, paste the path to your data inside the quotation marks
setwd("../R/")
## Import the "school.dat" data provided with Huberty & Olejnik's (2006)
## textbook, accessible here as "wintergreen.sav":
## ftp://ftp.wiley.com/public/sci_tech_med/applied_manova/
school <- read.table("school.dat", header = FALSE, na.strings = "-999",
                     col.names = c("ID","AA","PE","SM","AE","R","G","C"))



## ------------------------------------------
## Changing Data Types to the Correct `class`
## ------------------------------------------

## Before imputing data, we need to make sure the variables will be treated
## correctly (e.g., `R` and `G` should be treated as categorical, not numeric).

## Save copies of nominal variables as labeled `factor` variables.
school$religion <- factor(school$R, levels = c(0, 1, 2),
                          labels = c("Catholic","Protestant","Jewish"))
school$sex <- factor(school$G, levels = c(0, 1), labels = c("Male","Female"))
school$community <- factor(school$C, levels = c(0, 1),
                           labels = c("Urban","Rural"))

## Save copies of ordinal variables as labeled `ordered` `factor` variables.
school$motiv <- ordered(school$SM, levels = c(0, 1, 2),
                        labels = c("Unwilling","Undecided","Willing"))
school$eval <- ordered(school$AE, levels = c(0, 1, 2),
                       labels = c("Fail","Might Succeed","Succeed"))

## The variables `SM`, `AE`, `R`, `G`, and `C` are stored as `numeric` vectors,
## so they will not be treated correctly in the imputation procedures described
## below.  That is, only continuous variables should be treated as `numeric`,
## whereas nominal and ordinal `factor`s should be treated as having discrete
## categories.  Because `SM`, `AE`, `R`, `G`, and `C` are redundant with the
## variables `motivation`, `evaluation`, `religion`, `sex`, and `community`,
## respectively, we will simplify the presentation by removing the old columns
## `SM`, `AE`, `R`, `G`, and `C`.
school <- school[ , -4:-8]
head(school)



## ----------------------
## Summarize Missing Data
## ----------------------

## Identifying missing values can be done with the logical function is.na()
is.na(school$AA)
which(is.na(school$AA))

## User-defined function to summarize missingness on a single variable
propMiss <- function(x) {
  c(N = length(x), N.obs = sum(!is.na(x)),
    N.miss = sum(is.na(x)), Proportion.miss = mean(is.na(x)))
}
## Test it out on one variable
propMiss(school$AA)
## Now you can apply it to  each variable
sapply(school, propMiss)


## Both multiple-imputation packages I introduce below (`Amelia` and `mice`)
## provide some additional ways to summarize missing-data proportions or
## patterns, which you might find useful in more complicated circumstances.
install.packages(c("Amelia","mice")) # only need to install the first time

## `Amelia` provides a plot showing the "holes" in the `data.frame`
library(Amelia)
missmap(school)

## `mice` provides a table in which:
## - each row is a missing-data pattern
## - the left column is how many people have that pattern
## - the right column is how many variables are missing for that pattern
## - the bottom row is how many people are missing data for that variable
library(mice)
md.pattern(school)



## ----------------------------------------------------------
## Amelia: multiple imputation using a bootstrap-EM algorithm
## ----------------------------------------------------------

library(Amelia)

## This package transforms nominal variables into dummy codes, and ordinal
## variables are treated as having an underlying normal distribution, then
## the imputations are rounded so they fit into the ordinal categories.
## ID variables can be declared so that they are ignored.

## Before imputing data, you should choose a "Seed" so that you can
## reproduce your results (so no one can claim you "made up the data").
## Whereas the `mice()` function has an explicit argument to set the seed,
## if you use `amelia()` you must set the seed before running the function.
set.seed(12345)

## When imputing the missing data with Amelia, notice that we explicitly tell
## her that `ID` is an ID variable; `religion`, `sex`, and `community`
## are nominal factors; and `motivation` and `evaluation` are ordered factors.
## Any variables not explicitly declared this way are assumed continuous.
nImps <- 3 # in practice, better to use 100 imputations
out.amelia <- amelia(school, m = nImps, idvars = "ID",
                     noms = c("religion","sex","community"),
                     ords = c("motiv","eval"))
summary(out.amelia)


## Unlike the `mice()` output, `amelia()` output already contains a `list` of
## imputations.  Extract imputed datasets from the output object.
imps.amelia <- out.amelia$imputations
## view the last few rows of each imputation
lapply(imps.amelia, tail)
## compare to original data
tail(school)



## -------------------------------------------------
## Multiple Imputation with Chained Equations (MICE)
## -------------------------------------------------

library(mice)

## Chained equations apply a different imputation model for each variable, so
## appropriate values can be predicted for continuous, nominal, ordinal, and
## count variables.  There is no argument in mice() function to declare an
## ID variable, but a predictor matrix can be specified that tells mice() not
## to use the ID variable as a predictor in any imputation model.
predMat <- matrix(1, # 1 means "yes"
                  nrow = ncol(school), ncol = ncol(school),
                  dimnames = list(colnames(school), colnames(school)))
predMat[ , "ID"] <- 0 # 0 means "no"
## also, ID should not be imputed, so nothing should predict it
predMat["ID", ] <- 0
## And no variable should ever predict itself
diag(predMat) <- 0
## Variables without any missing data do not need to be imputed, so nothing
## should predict them (i.e., set their rows to zeros).
predMat[c("sex","motiv","eval"), ] <- 0
predMat
## This predictor matrix only allows main effects of each variable to be
## included or excluded.  To specify a more complex model, users can also
## specify a `formula` for each outcome, storing the formulas in a `list`.

## For example, to include a 2-way interaction between `sex` and `religion`
## (`sex*motivation`) but only main effects of other variables:
formulaList <- list(AA = AA ~ sex*motiv + PE + religion + eval + community,
                    PE = PE ~ sex*motiv + AA + religion + eval + community,
             religion  = religion ~ sex*motiv + AA + PE + eval + community,
             community = community ~ sex*motiv + AA + PE + religion + eval)
## Notice that no imputation models were specified for variables with complete
## data, and that no variable predicted itself.


## Because the variables are explicitly declared as nominal or ordinal factors,
## `mice()` will automatically choose appropriate imputation models.
sapply(school, class)
## However, the `method=` argument can be used to explicitly declare the types
## of model used for each variable, if necessary (e.g., for multilevel data).
## You would simply create a vector of `character` strings specifying the model
## for each variable, similar to the vector of `formula`s above (`formulaList`).

## Below, we impute the missing values `m = 3` times for simplicity, but in
## practice, `m = 100` is recommended to create a more representative sample
## of the possible values that could have been observed.  The `seed=` argument
## is used to make sure the same results can be replicated. The integer used
## (`12345`) is arbitrary, but using the same integer will reproduce results
## exactly.
nImps <- 3 # number of imputations
out.mice <- mice(school, m = nImps, seed = 12345,
                 predictorMatrix = predMat,
                 formulas = formulaList, # comment-out to omit interactions
                 printFlag = FALSE)

## To fit a structural equation model to multiply imputed data, you must
## extract imputed ("completed") data sets from the output object by
## applying the `complete()` function in a `for`-loop:
imps.mice <- list()
for (i in 1:nImps) imps.mice[[i]] <- complete(out.mice, action = i)
## view the last few rows of each imputation
lapply(imps.mice, tail)
## compare to original data
tail(school)



## -----------------------------
## SEM with Multiple Imputations
## -----------------------------

## The `semTools` package provides lavaan's functionality for multiply
## imputed data.  This section shows how to use it.

# If necessary:      install.packages("semTools")
library(semTools)

## First, to incorporate categorical predictors into a lavaan model, we
## must make dummy codes within each imputed data set.  Loop over the
## list of data sets (either `imps.mice` or `imps.amelia`):
for (m in 1:nImps) {
  imps.mice[[m]]$Male <- ifelse(imps.mice[[m]]$sex == "Male", yes = 1, no = 0)
  imps.mice[[m]]$Willing <- ifelse(imps.mice[[m]]$motiv == "Willing", 1, 0)
  imps.mice[[m]]$Unwilling <- ifelse(imps.mice[[m]]$motiv == "Unwilling", 1, 0)
}

## Because auxiliary variables were already used to predict missing values
## during imputation, the analysis model only needs to include variables
## of theoretical interest, like the models specified using FIML.
model <- '
  ## label main effects
    AA ~ sex*Male
    AA ~ motiv1*Willing + motiv2*Unwilling
  ## label interaction effects using ":"
    AA ~ int1*Male:Willing + int2*Male:Unwilling
'
## Now, we do not need to declare a "missing" argument because imputed
## data are complete.  But we need to fit the model to the `list` of data.
fit <- sem.mi(model, data = imps.mice, meanstructure = TRUE,
              warn = FALSE) # to prevent unnecesary warnings
summary(fit, rsquare = TRUE)
## Notice the slope labels are truncated in the output.

## We can use the labels to get ANOVA tests, but using the `anova()`
## function with the argument `test = "D1"` (Wald test for imputed data).
test.int <- '
  int1 == 0
  int2 == 0
'
anova(fit, constraints = test.int, test = "D1")
## Note that this is an F statistic, but we can also request a
## chi-squared test statistic that assumes the denominator *df* are large.
anova(fit, constraints = test.int, test = "D1", asymptotic = TRUE)

## Cannot reject null hypothesis, so remove the interaction from the model
model0 <- '
  ## label main effects
    AA ~ sex*Male
    AA ~ motiv1*Willing + motiv2*Unwilling
'
fit0 <- sem.mi(model0, data = imps.mice, meanstructure = TRUE, warn = FALSE)
summary(fit0, rsquare = TRUE) # Male slope is not significant
## test effect of motivation
test.main <- '
  motiv1 == 0
  motiv2 == 0
'
anova(fit0, constraints = test.main, test = "D1", asymptotic = TRUE) # significant



## An alternative to the Wald test (which only requires fitting an
## unrestricted model) is a Likelihood Ratio Test (LRT), which also
## requires fitting a restricted model **to the same variables** that
## represents the null hypothesis:
restricted.model <- '
## label main effects
AA ~ sex*Male
AA ~ motiv1*Willing + motiv2*Unwilling
## label interaction effects using ":"
AA ~ 0*Male:Willing + 0*Male:Unwilling
'
## Notice that instead of labels, we fixed the slopes of the interaction
## terms to be 0.  After fitting this model, we can use `anova()` to
## compare them.
restricted.fit <- sem.mi(restricted.model, data = imps.mice,
                         meanstructure = TRUE, warn = FALSE)
anova(restricted.fit, h1 = fit)
## Notice how similar the LRT result is to the Wald test result:
anova(fit, constraints = test.int, test = "D1")
## The LRT is useful when testing hypotheses that involve many parameters,
## or to compare models that are not nested in a simple way.






